[![Nuget count](http://img.shields.io/nuget/v/ACBr.Net.Consulta.svg)](https://www.nuget.org/packages/ACBr.Net.Consulta/)

# ACBr.Net.Consulta

Biblioteca para consulta de CNPJ e CPF na Receita Federal e para consulta de dados do IBGE